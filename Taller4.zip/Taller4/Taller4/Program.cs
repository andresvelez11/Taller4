﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taller4
{
    class Program
    {
        public static char tokendeentrada = ' ';
        public static char[] Operadores = { '+', '-', '*', '/' };
        public static int PosicionCinta = 0;
        public static string CadenaAnalizada = " ";

        static List<string> a = new List<string>();
        static string b = "";

        static string preorden = "";
        static string posorden = "";

        static int plus = 0, plusA = 0, minus = 0, minusA = 0, div = 0, divA = 0, mul=0, mulA=0;

        static void Main(string[] args)
        {
            string c = "a+b-bc*r*(7+1)"; //Expresion a analizar
            b = c;
            a = arithmeticOperations(c + ";");
            verify(b);
           
            int cont = 0;
            while (cont < a.Count)
            {
                CadenaAnalizada = a[cont];
                PosicionCinta = 0;

                tokendeentrada = Obtenertoken();
                expresion();

                if (tokendeentrada != ' ')
                {
                    Console.WriteLine(tokendeentrada);
                    Console.WriteLine("Sintaxis Invalida");
                }
                else
                {
                    Console.WriteLine("Esta Expresion esta Bien");

                }
                cont += 1;
            }

            Console.WriteLine("PREORDEN: " + preorden);
            Console.WriteLine("POSORDEN: " + posorden);

            Console.ReadLine();


        }

        static Boolean find(string expretion)
        {
            Boolean answer = false;
            char[] operators = { '+', '-', '*', '/' };
            int i = 0;

            while (answer == false && i < expretion.Length)
            {
                if (operators.Contains(expretion[i]) == true)
                {
                    answer = true;
                }

                i++;
            }


            return answer;
        }

        static List<string> arithmeticOperations(String code)
        {
            char[] separators = { ' ', '{', '}', ';', '[', ']', '<', '>', ':', '=', '.', '_', '"', '\'' };

            List<string> operationsList = new List<string>();

            string expression = null;
            char previous = ' ';
            char next = ' ';

            for (int i = 0; i < code.Length; i++)
            {
                if (i == 0)
                {
                    next = code[i + 1];
                }
                else if (i == code.Length - 1)
                {
                    previous = code[i - 1];
                }
                else
                {
                    previous = code[i - 1];
                    next = code[i + 1];
                }

                if (separators.Contains(code[i]) == true) //No puede ser alguno se los separadores
                {
                    if (find(expression) == true)
                    {
                        operationsList.Add(expression);
                        expression = "";
                    }
                    else
                    {
                        expression = "";
                    }

                }
                else
                {
                    expression = expression + code[i].ToString();
                }
            }

            return operationsList;
        }

        public static void expresion()
        {
            Preorder(b);
            termino();
            expresionprima();
        }

        public static void expresionprima()
        {

            if (tokendeentrada != ' ')
            {
                if (tokendeentrada == '+')
                {
                  
                    HacerMatch('+');
                    termino();
                    posorden = posorden + "+";
                    expresionprima();

                }

                else
                {
                    if (tokendeentrada == '-')
                    {
                        HacerMatch('-');
                        termino();
                        posorden = posorden + "-";
                        expresionprima();
                    }
                    else
                    {
                        return;
                    }
                }
            }
        }


        public static void termino()
        {
            fact();
            Preorder(b);
            terminoprima();
        }

        public static void terminoprima()
        {

            if (tokendeentrada != ' ')
            {
                if (tokendeentrada == '*')
                {
                    HacerMatch('*');
                    fact();
                    posorden = posorden + "*";
                    terminoprima();
                }
                else
                {
                    if (tokendeentrada == '/')
                    {
                        HacerMatch('/');
                        fact();
                        posorden = posorden + "/";
                        terminoprima();
                    }
                    else
                    {
                        return;
                    }
                }
            }
        }

        public static void fact()
        {
            if (tokendeentrada != ' ')
            {
                if (tokendeentrada == '(')
                {
                    preorden = preorden + "(";
                    HacerMatch('(');
                    expresion();
                    if (tokendeentrada == ')')
                    {
                        preorden = preorden + ")";
                        HacerMatch(')');
                    }
                    else
                    {
                        Console.Write("Se esperba un )\n");
                    }
                }
                else
                {
                    if (Char.IsDigit(tokendeentrada))
                    {
                        numero();
                    }
                    else
                    {
                        ident();
                    }
                }

            }
        }



        public static void numero()
        {
            digit();
            numeroprima();
        }


        public static void numeroprima()
        {

            if (tokendeentrada != ' ')
            {
                if (Char.IsDigit(tokendeentrada))
                {
                    digit();
                    numeroprima();
                }
                else
                {
                    return;
                }
            }
        }


        public static void digit()
        {
            if (tokendeentrada != ' ')
            {
                if (Char.IsDigit(tokendeentrada))
                {
                    preorden = preorden + tokendeentrada;
                    posorden = posorden + tokendeentrada;
                    HacerMatch(tokendeentrada);
                }
                else
                {
                    Console.WriteLine("Se esperaba un digito");
                }
            }
        }


        public static void ident()
        {
            letra();
            identprima();
        }

        public static void identprima()
        {

            if (tokendeentrada != ' ')
            {
                if (Char.IsLetter(tokendeentrada))
                {
                    letra();
                    identprima();
                }
                else
                {
                    return;
                }
            }
        }

        public static void letra()
        {

            if (tokendeentrada != ' ')
            {
                if (Char.IsLetter(tokendeentrada))
                {
                    preorden = preorden + tokendeentrada;
                    posorden = posorden + tokendeentrada;
                    HacerMatch(tokendeentrada);
                }
                else
                {
                    Console.WriteLine("Se esperaba una letra o constante");
                }
            }
        }

        public static void HacerMatch(char t)
        {

            if (t != ' ')
            {
                if (t == tokendeentrada)
                {
                    tokendeentrada = Obtenertoken();
                }
                else
                {
                    Console.WriteLine("Se esperaba: " + tokendeentrada);
                }
            }
        }

        public static char Obtenertoken()
        {

            if (PosicionCinta + 1 <= (CadenaAnalizada).Length)
            {
                if (Operadores.Contains(CadenaAnalizada[PosicionCinta]) && Operadores.Contains(CadenaAnalizada[PosicionCinta + 1]))
                {
                    tokendeentrada = CadenaAnalizada[PosicionCinta];
                    Console.WriteLine("se esperaba un digito o variable y no un '" + CadenaAnalizada[PosicionCinta + 1] + "'");
                    return ' ';
                }
                else
                {
                    PosicionCinta += 1;
                    return CadenaAnalizada[PosicionCinta - 1];
                }


            }
            return ' ';
        }

        public static void verify(string operation)
        {
            for(int i = 0; i< operation.Count(); i++)
            {
                switch (operation[i])
                {
                    case '+':
                        plus++;
                        break;
                    case '-':
                        minus++;
                        break;
                    case '*':
                        mul++;
                        break;
                    case '/':
                        div++;
                        break;
                    
                }
            }
        }

        public static void Preorder(String operation)
        {
            Boolean a = true;
            int i=0;
            while (a == true && i < operation.Length)
            {
                if(operation[i] == '+' && plusA<plus)
                {
                    preorden = preorden + "+";
                    plusA++;
                    a = false;
                }
                else if(operation[i] == '-' && minusA<minus)
                {
                    preorden = preorden + "-";
                    minusA++;
                    a = false;
                }
                else if (operation[i] == '*' && mulA<mul)
                {
                    preorden = preorden + "*";
                    mulA++;
                    a = false;
                }
                else if (operation[i] == '/' && divA<div)
                {
                    preorden = preorden + "/";
                    divA++;
                    a = false;
                }

                i++;

            }
            
        }
    }
}
